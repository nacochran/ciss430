-- description.sql
-- Nathan Cochran

USE movie_db;

DESC character_principal;
DESC crew;
DESC director;
DESC genre;
DESC known_title;
DESC name;
DESC name_basic_profession;
DESC profession;
DESC rating;
DESC title;
DESC titles_basic_genres;
DESC writer;
