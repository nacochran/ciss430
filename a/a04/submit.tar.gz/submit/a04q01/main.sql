
USE movie_db;

DESC character_principal;

DESC crew;

DESC director;

DESC genre;

DESC known_title;

DESC name;

DESC name_basic_profession;

DESC principal;

DESC profession;

DESC rating;

DESC title;

DESC titles_basic_genre;

DESC writer;
